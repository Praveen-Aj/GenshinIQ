"""API module for GenshinIQ."""
